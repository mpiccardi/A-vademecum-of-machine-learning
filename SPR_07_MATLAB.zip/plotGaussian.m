% plot the Gaussians by canonical parameters

clear;

start = -1;
stop = 6;
step = 0.1;

mu = 2;
sigma = 0.75;

theta_2 = -1/(2 * sigma^2)
theta_1 = mu/sigma^2
A = mu^2/(2 * sigma^2) + 0.5 * log(2 * pi * sigma^2)

i = 1;
for x = start:step:stop
  curve_2(i) = exp(theta_2 * x^2);
  i = i + 1;
end

figure;
plot(start:step:stop, curve_2, 'red');

i = 1;
for x = start:step:stop
  curve_1(i) = exp(theta_1 * x);
  i = i + 1;
end

figure;
plot(start:step:stop, curve_1, 'green');

i = 1;
for x = start:step:stop
  curve_0(i) = exp(-A);
  i = i + 1;
end

figure;
plot(start:step:stop, curve_0, 'yellow');

product = curve_0 .* curve_1 .* curve_2;

figure;
plot(start:step:stop, product, 'black');

% for comparison:

Gaussian = pdf('norm', start:step:stop, mu, sigma);

hold; plot(start:step:stop, Gaussian + 0.005, 'blue'); 
