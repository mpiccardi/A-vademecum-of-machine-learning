% Simple CRF example
% From, and requiring: HCRF2.0b toolbox by Louis-Philippe Morency

% sampleData contains 102 short training sequences and 1 long test sequence
% States are binary (0/1)
% 1: gaze aversion; 0: normal gaze
% Reference for the dataset: L.-P. Morency, C. M. Christoudias and T. Darrell, 
% "Recognizing Gaze Aversion Gestures in Embodied Conversational Discourse", ICMI 2006

load sampleData;

paramsData.weightsPerSequence = ones(1,128) ;
paramsData.factorSeqWeights = 1;

paramsNodCRF.normalizeWeights = 1;
R{1}.params = paramsNodCRF;
[R{1}.model R{1}.stats] = train(trainSeqs, trainLabels, R{1}.params);
[R{1}.ll R{1}.labels] = test(R{1}.model, testSeqs, testLabels);

% the above does not provide sequential decoding: just a separate
% posterior probability for each state (ll); with the notation of our
% slides, it is:
% p(y_t | x_{1:T}), i.e. the marginal probability of each state given all
% the measurements.
% NB: the returned labels are just a replica of testLabels (see sources).

% argmax(ll) (prediction based on the states' marginal probabilities):

[value, index] = max(R{1}.ll{1});
index = index - 1; % from 1/2 to 0/1

% prints the total error rate over the test sequence:
error_rate_CRF = sum(abs(index - testLabels{1}))/ size(index,2)

% repeat using a sliding-window HCRF of window size 32:
paramsNodHCRF.normalizeWeights = 1;
R{2}.params = paramsNodHCRF;
[R{2}.model R{2}.stats] = train(trainCompleteSeqs, trainCompleteLabels, R{2}.params);
[R{2}.ll R{2}.labels] = test(R{2}.model, testSeqs, testLabels);

[value, index] = max(R{2}.ll{1});
index = index - 1; % from 1/2 to 0/1

% prints the total error rate over the test sequence:
error_rate_HCRF = sum(abs(index - testLabels{1}(1:size(index,2))))/ size(index,2)
