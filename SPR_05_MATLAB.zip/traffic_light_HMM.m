re-hash
% Small example of HMM learning, rehashed from Kevin Murphy's
% "dhmm_em_demo".
% The example simulates a hypothetical traffic light operating in two states ("rush
% hour" and "normal").
% Requires the HMM Toolbox for Matlab by Kevin Murphy.

Q = 2; % number of values for the state variables
O = 3; % number of values for the observation variables

% "true" parameters:
prior0 = [1 0];
transmat0 = [0.95 0.05; 0.20 0.80];
mk_stochastic(transmat0)
obsmat0 = [0.45	0.10 0.45; 0.20	0.10 0.70];
mk_stochastic(obsmat0)

% training data, sampled from the true model:
T = 100;
nex = 20;
data = dhmm_sample(prior0, transmat0, obsmat0, T, nex);

% learning of the HMM from the training data:

% initial, arbitrary guess of parameters needed by EM:
prior1 = [0.8 0.2];
transmat1 = [0.8 0.2; 0.2 0.8];
mk_stochastic(transmat1)
obsmat1 = [0.5 0.25 0.25; 1/3 1/3 1/3];
mk_stochastic(obsmat1)

% learned parameters using EM:
[LL, prior2, transmat2, obsmat2] = dhmm_em(data, prior1, transmat1, obsmat1, 'max_iter', 200);

% parameters learned:
prior2
transmat2
obsmat2

% for comparison:
% prints the log-likelihood of the sample in the true model:
loglik_data_model0 = dhmm_logprob(data, prior0, transmat0, obsmat0)

% prints the log-likelihood of the samples in the initial, arbitrary model:
loglik_data_model1 = dhmm_logprob(data, prior1, transmat1, obsmat1)

% prints the log-likelihood of the samples in the learned model:
loglik_data_model2 = dhmm_logprob(data, prior2, transmat2, obsmat2)
% (can it be higher than in the "true" model? Is it desirable?)

% for comparison, obtains a second sample from the true model: 
data2 = dhmm_sample(prior0, transmat0, obsmat0, T, nex);

% prints the log-likelihood of these samples in the true model:
loglik_data2_model0 = dhmm_logprob(data2, prior0, transmat0, obsmat0)

% prints the log-likelihood of the samples in the learned model:
loglik_data2_model2 = dhmm_logprob(data2, prior2, transmat2, obsmat2)
% (which one was higher this time, and why?)


