% Example of simple regression.

clear;

N = 1000;

% generates N samples for X from a gamma distribution:
k = 3;
theta = 2;
location = 7;
x = random('gam', k, theta, N, 1) + location; % x is N x 1
x = [x repmat(1,N,1)] % adds a column of all 1 to x; x is now N x 2

% generates N samples for Y from a t distribution conditioned on the values of X:
w = -0.8;
b = 10;
nu = 2;
for i=1:N
  y(i) = w * x(i) + b + random('t', nu); % y is 1 x N
end
y = y'; % y is now N x 1  

%plots the x-y points:
scatter(x(:,1),y)

% computes the least square estimate for w,b in three different ways.
% Results are the same in this case, but algorithms are different:

w_ls = x\y % Matlab famous 'backslash' operator; uses QR decomposition
w_ls = inv(x' * x) * x' * y % squaring x causes loss of numerical accuracy
w_ls = pinv(x) * y % pinv uses SVD decomposition 
w_ls = regress(y,x)

% plots a line from the estimated parameters:
hold;
t = location - 5 : 0.1 : location + 25;
line(t, w_ls(1) * t + w_ls(2),'Color','red', 'LineStyle','--');