% PCA 3D to 2D

mu1 = [3 5 6]; % as a row vector
sigma1 = [1 0 0; 0 3 0; 0 0 8]; % as row vectors
X(1:150,:) = mvnrnd(mu1, sigma1, 150);

mu2 = [-5 8 2]; % as a row vector
sigma2 = [5 0 0; 0 3 0; 0 0 1]; % as row vectors
X(151:300,:) = mvnrnd(mu2, sigma2, 150); % N x 3

scatter3(X(:,1),X(:,2),X(:,3)); hold;
xlabel('x1');
ylabel('x2');
zlabel('x3');

mu = mean(X); % 3 x 1
mus = reshape(repmat(mu',size(X,1), 1), 3, size(X,1));
mus = mus'; % repeated means, N x 3

X0 = X - mus; % mean-centred data, N x 3
S = cov(X0) % covariance, 3 x 3
rank_S = rank(S)
[U,l] = eigs(S); % largest eigenvalue: right-most column
W = U(:,1:2) % PCA matrix, 3 x 2
WT = W'; % 2 x 3
XP = (WT * X0')'; % projected data, N x 2
XR = ((WT' * XP')' + mus); % reconstructed data, N x 3 

SR = cov(XR)  % covariance of reconstructed data, N x 3
rank_SR = rank(SR)

scatter3(XR(:,1),XR(:,2),XR(:,3), 'red');

k = 10;
line([(mu(1) - k * U(1,1)) (mu(1) + k * U(1,1))], [(mu(2) - k * U(2,1)) (mu(2) + k * U(2,1))], [(mu(3) - k * U(3,1)) (mu(3) + k * U(3,1))], 'Color', 'red','LineWidth',1.5);
k = 6;
line([(mu(1) - k * U(1,2)) (mu(1) + k * U(1,2))], [(mu(2) - k * U(2,2)) (mu(2) + k * U(2,2))], [(mu(3) - k * U(3,2)) (mu(3) + k * U(3,2))], 'Color', 'red','LineWidth',1.5);