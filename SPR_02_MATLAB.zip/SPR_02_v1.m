% Classification example.
% 3 classes: apples, avocados and pears.
% 1-D measurement: the ratio between the maximum diameter of a piece
% of fruit and its orthogonal diameter; should have a minimum of 1.
% Classification by:
% - maximum a posteriori decision rule
% - minimum risk decision rule
% NB: data are made up.

fprintf(1,'\n*************************************************************************************************************');
fprintf(1,'\nBayesian classification: a fictional example with three classes: apples, avocados, pears, and one measurement');
fprintf(1,'\n*************************************************************************************************************\n');

delete(findall(0,'Type','figure')); % closes all opened figures

% first likelihood is for apples. Gaussian pdf of parameters:

mu1 = 1.2;
sigma1 = 0.2;

% second likelihood is for avocados. GMM of parameters:

mu2 = [1.5; 2.0];
sigma2 = cat(3,0.02,0.02);
p2(1) = 0.67; p2(2) = 0.33;
obj = gmdistribution(mu2,sigma2,p2);

% third likelihood is for pears. Gaussian pdf of parameters:

mu3 = 2.5;
sigma3 = 0.4;

% plot the likelihoods, p(x|c):

fprintf(1,'\nPlotting the likelihoods...\n');
hold('on');
set(figure(1),'Name','likelihoods','Numbertitle','off')
title('likelihoods');
plot(0:0.02:4, pdf('norm',0:0.02:4,mu1,sigma1), 'blue')
plot(0:0.02:4, pdf(obj,[0:0.02:4]'),'red')
plot(0:0.02:4, pdf('norm',0:0.02:4,mu3,sigma3),'green')

% now we choose arbitrary priors for the likelihoods:

p(1) = 0.5;
p(2) = 0.2;
p(3) = 0.3;

% plot the joint probabilities, p(x,c):

fprintf(1,'\nPlotting the joint probabilities...\n');
figure; hold('on');
set(figure(2),'Name','joint probabilities','Numbertitle','off')
title('joint probabilities');
jp1 = p(1) * pdf('norm',0:0.02:4,mu1,sigma1);
jp2 = (p(2) * pdf(obj,[0:0.02:4]'))';
jp3 = p(3) * pdf('norm',0:0.02:4,mu3,sigma3);
plot(0:0.02:4, jp1, 'blue')
plot(0:0.02:4, jp2, 'red')
plot(0:0.02:4, jp3, 'green')

% plot the posterior probabilities, p(c|x):

mp = jp1 + jp2 + jp3; % marginal probability of the measurements in the interval

pp1 = jp1 ./ mp;
pp2 = jp2 ./ mp;
pp3 = jp3 ./ mp;

figure; hold('on');
set(figure(3),'Name','posterior probabilities','Numbertitle','off')
title('posterior probabilities');
plot(0:0.02:4, pp1, 'blue')
plot(0:0.02:4, pp2, 'red')
plot(0:0.02:4, pp3, 'green')

% now we choose an arbitrary test sample:

fprintf(1,'\nTest sample:\n');
x = 1.4

% compute and display the likelihoods for the sample:

l(1) = pdf('norm',x,mu1,sigma1);
l(2) = pdf(obj,x);
l(3) = pdf('norm',x,mu3,sigma3);

fprintf(1,'\nLikelihoods for the sample:\n');
l

% display the priors:
fprintf(1,'\nClass priors:\n');
p

% compute and display the joint probabilities for the sample:

jp(1) = p(1) * pdf('norm',x,mu1,sigma1);
jp(2) = p(2) * pdf(obj,x);
jp(3) = p(3) * pdf('norm',x,mu3,sigma3);

fprintf(1,'\nJoint probabilities for the sample:\n');
jp

% compute and display the posterior probabilties for the sample:

fprintf(1,'\nPosterior probabilities for the sample:\n');
pp = jp/sum(jp)

% apply MAP decision rule:

[value, class] = max(pp);

fprintf(1,'Based on MAP, the assigned class is: %d\n', class);

% Now we add a cost function: we start with the zero-one loss:

fprintf(1,'\nDisplay the zero-one cost function:\n');
zero_one = [0 1 1; 1 0 1; 1 1 0]

fprintf(1,'\nClass costs for the sample with the zero-one loss:\n');
costs = pp * zero_one'

[value, class] = min(costs);

fprintf(1,'Based on the zero-one cost function, the assigned class is: %d\n', class);

% Let us choose a different cost function:

fprintf(1,'\nDisplay a second cost function (big reputation damage if you put an apple in place of an avocado or pear):\n');
other = [0 2 2; 0.2 0 0.3; 0.1 1 0] % rows: true classes; columns; assigned classes
                                    % big reputation damage if you put an apple in place of an avocado or pear

fprintf(1,'\nClass costs for the sample with the second cost function:\n');
costs = pp * other'

[value, class] = min(costs);

fprintf(1,'Based on this cost function, the assigned class is: %d\n', class);

% plot the cost as a function of x for the second cost function:

cost1 = other(1,1) * pp1 + other(2,1) * pp2 + other(3,1) * pp3;
cost2 = other(1,2) * pp1 + other(2,2) * pp2 + other(3,2) * pp3;
cost3 = other(1,3) * pp1 + other(2,3) * pp2 + other(3,3) * pp3;

figure; hold('on');
set(figure(4),'Name','cost as a function of x for the second cost function','Numbertitle','off')
title('cost as a function of x for the second cost function');
plot(0:0.02:4, cost1, 'blue')
plot(0:0.02:4, cost2, 'red')
plot(0:0.02:4, cost3, 'green')