% This program draws samples from the bivariate Gaussian distribution
% N(Y|mu,S) in two ways:
% 1: by using mvnrnd
% 2: by using randn and properties of linear combinations of the Gaussian

mu = [-3 5]; % as a 1 x 2 vector
S = [0.61 0.48; 0.48 0.64]; % 2 x 2

Y = mvnrnd(mu, S, 10000); % Y is 10,000 x 2
scatter(Y(:,1),Y(:,2), 'blue')
hold

% or!:

W = chol(S); % W is 2 x 2
X = randn(1, 20000); % 20,000 1-D Gaussian samples; X is 1 x 20,000
X = reshape(X, 10000, 2); % reshapes X into a 2-D vector with 10,000 elements
                          % X is now 10,000 x 2
Y = X * W + repmat(mu,10000,1);  % Y is 10,000 x 2
scatter(Y(:,1),Y(:,2), 'red')
