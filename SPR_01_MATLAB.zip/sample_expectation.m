% This program computes a sample expectation for function:
% f(x) = x^2 - x - 1 if -2 <= x <= 2
% f(x) = 0   otherwise
% over distribution N(x|1,1)

% NB: inefficient code!

clear; 
N = 100;

i = 0;
while i < N
    X(i+1) = random('norm',1,1,1); % randn(1) + 1;
    i = i + 1;   
end
 
for i = 1:N
    if (X(i) >= -2 && X(i) <= 2)
        fun(i) = X(i)^2 - X(i) - 1;
    else
        fun(i) = 0;
    end
     
end

plot(X,1,'+')
hold on;
scatter(X, fun)
mean(fun)