% This program draws samples from a 2-D Gaussian mixture model
% with two components.
% Code rearranged from Matlab Help, �Gaussian Mixture Models� and
% �gmdistribution�.

mu = [1 2;-3 -5];
sigma = cat(3,[2 0;0 .5],[1 0;0 1]);
p(1) = 0.75; p(2) = 0.25;
obj = gmdistribution(mu,sigma,p);
Y = random(obj,1000);
scatter(Y(:,1),Y(:,2), 'xr')
hold on
h = ezcontour(@(x,y)pdf(obj,[x y]),[-8 6],[-8 6]);
